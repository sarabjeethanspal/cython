def print_name(name):
	print("Name is {}".format(name))
